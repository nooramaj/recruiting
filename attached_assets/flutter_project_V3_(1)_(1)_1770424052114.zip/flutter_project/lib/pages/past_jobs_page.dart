import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../models/job_model.dart';
import 'edit_job_page.dart';

class PastJobsPage extends StatelessWidget {

  void _deleteJob(BuildContext context, String jobId) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title:  Text("Delete Job?"),
        content:  Text("Are you sure you want to remove this job?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child:  Text("Cancel")),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await FirebaseFirestore.instance.collection('jobs').doc(jobId).delete();
            },
            child:  Text("Delete", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(title:  Text("My Past Jobs"), backgroundColor: Colors.blueAccent),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('jobs')
            .where('postedByUserId', isEqualTo: uid)
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) return  Center(child: CircularProgressIndicator());
          if (snapshot.data!.docs.isEmpty) return  Center(child: Text("No jobs posted yet."));

          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              final doc = snapshot.data!.docs[index];
              Job job = Job.fromMap(doc.id, doc.data() as Map<String, dynamic>);

              return Card(
                margin:  EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                child: ListTile(
                  title: Text(job.title),
                  subtitle: Text("Salary: ${job.salary}"),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon:  Icon(Icons.edit, color: Colors.blue),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => EditJobPage(job: job)),
                          );
                        },
                      ),
                      IconButton(
                        icon:  Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteJob(context, job.id),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}