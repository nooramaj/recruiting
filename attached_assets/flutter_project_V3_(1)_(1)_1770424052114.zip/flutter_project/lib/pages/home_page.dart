import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../main.dart';
import 'login_page.dart';
import 'post_job_page.dart';
import 'past_jobs_page.dart';
import 'details_page.dart';
import '../models/job_model.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Freelance Jo"),
        backgroundColor: Colors.blueAccent,
        actions: [
          IconButton(
            icon: Icon(themeNotifier.value == ThemeMode.light
                ? Icons.dark_mode
                : Icons.light_mode),
            onPressed: () {
              themeNotifier.value = themeNotifier.value == ThemeMode.light
                  ? ThemeMode.dark
                  : ThemeMode.light;
            },
          ),
          PopupMenuButton<String>(
            onSelected: (value) async {
              if (value == "post") {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => PostJobPage()),
                );
              } else if (value == "past") {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => PastJobsPage()),
                );
              } else if (value == "logout") {
                await FirebaseAuth.instance.signOut();
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => LoginPage()),
                );
              }
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: "post", child: Text("Host Job")),
              PopupMenuItem(value: "past", child: Text("My Past Jobs")),
              PopupMenuItem(value: "logout", child: Text("Logout")),
            ],
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              "Available job opportunities:",
              style: TextStyle(fontSize: 20,),
            ),
            SizedBox(height: 15),
            Expanded(
              child: StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection('jobs')
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
                builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (!snapshot.hasData)
                    return Center(child: CircularProgressIndicator());
                  if (snapshot.data!.docs.isEmpty)
                    return Center(child: Text("No jobs available."));

                  return ListView.builder(
                    itemCount: snapshot.data!.docs.length,
                    itemBuilder: (context, index) {
                      final doc = snapshot.data!.docs[index];
                      Job job = Job.fromMap(
                        doc.id,
                        doc.data() as Map<String, dynamic>,
                      );
                      return _jobBox(context, job);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _jobBox(BuildContext context, Job job) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => DetailsScreen(job: job)),
        );
      },
      child: Card(
        elevation: 6,
        margin: EdgeInsets.symmetric(vertical: 6),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(35),
          side: BorderSide(color: Colors.blueAccent),
        ),
        child: ListTile(
          leading: Icon(Icons.work_outline,),
          title: Text(
            job.title,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          subtitle: Text("Salary: ${job.salary} - ${job.location}"),
        ),
      ),
    );
  }
}
