import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'home_page.dart';

class PostJobPage extends StatefulWidget {
  @override
  State<PostJobPage> createState() => _PostJobPageState();
}

class _PostJobPageState extends State<PostJobPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  final _salaryController = TextEditingController();
  final _ageController = TextEditingController();
  String city = "Amman";
  bool _isLoading = false;
  final List<String> cities = ["Amman", "Irbid", "Ajloun", "AL-Zarqaa"];

  Future<void> _postJob() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      final phone = userDoc.data()?['phone'] ?? "";

      await FirebaseFirestore.instance.collection('jobs').add({
        'title': _titleController.text.trim(),
        'description': _descController.text.trim(),
        'salary': _salaryController.text.trim(),
        'minAge': _ageController.text.trim(),
        'location': city,
        'postedByUserId': user.uid,
        'contactPhone': phone,
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (mounted)
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => HomePage()),
        );
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Post Job"),
        backgroundColor: Colors.blueAccent,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(32),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _titleController,
                      validator: (v) => v!.isEmpty ? "Required" : null,
                      decoration: InputDecoration(labelText: "Job Title"),
                    ),
                    SizedBox(height: 15),
                    TextFormField(
                      controller: _descController,
                      maxLines: 3,
                      validator: (v) => v!.isEmpty ? "Required" : null,
                      decoration: InputDecoration(labelText: "Description"),
                    ),
                    SizedBox(height: 15),
                    TextFormField(
                      controller: _salaryController,
                      validator: (v) => v!.isEmpty ? "Required" : null,
                      decoration: InputDecoration(labelText: "Salary"),
                    ),
                    SizedBox(height: 15),
                    TextFormField(
                      controller: _ageController,
                      keyboardType: TextInputType.number,
                      validator: (v) => v!.isEmpty ? "Required" : null,
                      decoration: InputDecoration(labelText: "Min Age"),
                    ),
                    SizedBox(height: 15),
                    DropdownButton<String>(
                      value: city,
                      items: cities
                          .map(
                            (c) => DropdownMenuItem(value: c, child: Text(c)),
                          )
                          .toList(),
                      onChanged: (v) => setState(() => city = v!),
                    ),
                    SizedBox(height: 25),
                    ElevatedButton(
                      onPressed: _postJob,
                      child: Text("Post Job"),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
