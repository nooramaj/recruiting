import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/job_model.dart';

class EditJobPage extends StatefulWidget {
  final Job job;

  const EditJobPage({required this.job});

  @override
  State<EditJobPage> createState() => _EditJobPageState();
}

class _EditJobPageState extends State<EditJobPage> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _titleController;
  late TextEditingController _descController;
  late TextEditingController _salaryController;
  late TextEditingController _ageController;

  String city = "Amman";
  bool _isLoading = false;
  final List<String> cities = ["Amman", "Irbid", "Ajloun", "AL-Zarqaa"];

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.job.title);
    _descController = TextEditingController(text: widget.job.description);
    _salaryController = TextEditingController(text: widget.job.salary);
    _ageController = TextEditingController(text: widget.job.minAge);

    if (cities.contains(widget.job.location)) {
      city = widget.job.location;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    _salaryController.dispose();
    _ageController.dispose();
  }

  Future<void> _updateJob() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    try {
      await FirebaseFirestore.instance
          .collection('jobs')
          .doc(widget.job.id)
          .update({
            'title': _titleController.text.trim(),
            'description': _descController.text.trim(),
            'salary': _salaryController.text.trim(),
            'minAge': _ageController.text.trim(),
            'location': city,
          });

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Job Updated Successfully!")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e"), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Job"),
        backgroundColor: Colors.blueAccent,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(32),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _titleController,
                      validator: (v) => v!.isEmpty ? "Required" : null,
                      decoration: InputDecoration(labelText: "Job Title"),
                    ),
                    SizedBox(height: 15),
                    TextFormField(
                      controller: _descController,
                      maxLines: 3,
                      validator: (v) => v!.isEmpty ? "Required" : null,
                      decoration: InputDecoration(labelText: "Description"),
                    ),
                    SizedBox(height: 15),
                    TextFormField(
                      controller: _salaryController,
                      validator: (v) => v!.isEmpty ? "Required" : null,
                      decoration: InputDecoration(labelText: "Salary"),
                    ),
                    SizedBox(height: 15),
                    TextFormField(
                      controller: _ageController,
                      keyboardType: TextInputType.number,
                      validator: (v) => v!.isEmpty ? "Required" : null,
                      decoration: InputDecoration(labelText: "Min Age"),
                    ),
                    SizedBox(height: 15),
                    DropdownButtonFormField<String>(
                      initialValue: city,
                      items: cities
                          .map(
                            (c) => DropdownMenuItem(value: c, child: Text(c)),
                          )
                          .toList(),
                      onChanged: (v) => setState(() => city = v!),
                      decoration: InputDecoration(labelText: "Location"),
                    ),
                    SizedBox(height: 25),
                    ElevatedButton(
                      onPressed: _updateJob,
                      style: ElevatedButton.styleFrom(
                        side: BorderSide(color: Colors.blueAccent, width: 2),
                      ),
                      child: Text("Save Changes"),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
