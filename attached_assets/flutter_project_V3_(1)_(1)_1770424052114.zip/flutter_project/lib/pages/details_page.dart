import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/job_model.dart';

class DetailsScreen extends StatelessWidget {
  final Job job;

  DetailsScreen({required this.job});

  void _openWhatsApp(BuildContext context) async {
    String phone = job.contactPhone;
    final url = Uri.parse("https://wa.me/$phone");

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Could not open WhatsApp")));
    }
  }

  @override
  Widget build(BuildContext context) {
    String dateStr = "";
    DateTime date = job.createdAt!.toDate();
    dateStr = "${date.year}/${date.month}/${date.day}";

    return Scaffold(
      appBar: AppBar(
        title: Text("Job Details"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: EdgeInsets.all(32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Job Title: ${job.title}",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 5),

            Text(
              "Posted on: $dateStr",
              style: TextStyle(fontSize: 14),
            ),

            Divider(height: 30),

            Text("Description: ${job.description}"),
            SizedBox(height: 10),
            Text("Salary: ${job.salary}"),
            SizedBox(height: 10),
            Text("Min Age: ${job.minAge}"),
            SizedBox(height: 10),
            Text("Location: ${job.location}"),
            SizedBox(height: 30),

            Center(
              child: GestureDetector(
                onTap: () => _openWhatsApp(context),
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.green, width: 2),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.message, color: Colors.green),
                      SizedBox(width: 10),
                      Text(
                        "Apply via WhatsApp",
                        style: TextStyle(
                          color: Colors.green,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
