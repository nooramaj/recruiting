import 'package:cloud_firestore/cloud_firestore.dart';

class Job {
  String id;
  String title;
  String description;
  String salary;
  String minAge;
  String location;
  String postedByUserId;
  String contactPhone;
  Timestamp? createdAt;

  Job({
    required this.id,
    required this.title,
    required this.description,
    required this.salary,
    required this.minAge,
    required this.location,
    required this.postedByUserId,
    required this.contactPhone,
    this.createdAt,
  });

  factory Job.fromMap(String id, Map<String, dynamic> map) {
    return Job(
      id: id,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      salary: map['salary'] ?? '',
      minAge: map['minAge'] ?? '',
      location: map['location'] ?? '',
      postedByUserId: map['postedByUserId'] ?? '',
      contactPhone: map['contactPhone'] ?? '',
      createdAt: map['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'salary': salary,
      'minAge': minAge,
      'location': location,
      'postedByUserId': postedByUserId,
      'contactPhone': contactPhone,
      'createdAt': createdAt ?? FieldValue.serverTimestamp(),
    };
  }
}
