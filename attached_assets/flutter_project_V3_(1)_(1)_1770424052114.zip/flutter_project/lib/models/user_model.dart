class UserModel {
  String id;
  String name;
  String email;
  String age;
  String phone;
  String imageUrl;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.age,
    required this.phone,
    required this.imageUrl,
  });

  factory UserModel.fromMap(String id, Map<String, dynamic> map) {
    return UserModel(
      id: id,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      age: map['age'] ?? '',
      phone: map['phone'] ?? '',
      imageUrl: map['imageUrl'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'age': age,
      'phone': phone,
      'imageUrl': imageUrl,
    };
  }
}
